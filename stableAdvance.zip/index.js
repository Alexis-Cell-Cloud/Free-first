function updateGreeting(){
  let greet = document.getElementB("greet");
  let date = new date();
  let hour = now.getHours();
  //condition for greeting
  if(Hour < 12){
    greet.innerText = "🌝 good morning, welcome to home of african stories."
  } else if(Hour < 17){
    greet.innerText = "🌞 good afternoon,welcome back."
  } else{
    greet.innerText = "⭐ good evening, nice to see you again."
  }
  // Keep checking every minute (60,000 ms)
  setInterval(updateGreeting, 60000);
  
